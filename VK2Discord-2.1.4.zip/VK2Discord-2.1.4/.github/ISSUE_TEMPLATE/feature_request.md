---
name: Feature request
about: Предложите идею для скрипта
title: "[Feature request]"
labels: enhancement
assignees: ''

---

**Описание возможности**
Чёткое описание.
