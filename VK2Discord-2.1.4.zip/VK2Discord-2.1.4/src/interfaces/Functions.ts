export interface GetPostLinkOptions {
    owner_id: number;
    id: number;
}

export interface Profile {
    name: string;
    photo_50?: string;
}
